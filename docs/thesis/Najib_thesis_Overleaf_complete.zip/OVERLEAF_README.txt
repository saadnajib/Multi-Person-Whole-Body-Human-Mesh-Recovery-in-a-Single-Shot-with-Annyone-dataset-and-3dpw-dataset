Complete thesis source from main, 8 Nov 2026 (temperature sweep filled in).

In Overleaf: New Project > Upload Project > select this ZIP.
Main document: thesis.tex (at the project root).
Compiler: pdfLaTeX. Use a current TeX Live version.
Upload the complete archive; do not upload only the chapter files.
Keep figures/tikz, figures/plots, figures/img, tables and data in place.
The bibliography uses biblatex with biber (Overleaf handles it automatically).
The only remaining TODO is the author's approval of the AI-use statement.
