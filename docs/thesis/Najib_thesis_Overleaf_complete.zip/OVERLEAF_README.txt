Complete thesis source, 13 Nov 2026 (supervisor feedback applied; distillation ablation and sweep validation results included).

In Overleaf: New Project > Upload Project > select this ZIP.
Main document: thesis.tex (at the project root).
Compiler: pdfLaTeX. Use a current TeX Live version.
Upload the complete archive; do not upload only the chapter files.
Keep figures/tikz, figures/plots, figures/img, tables and data in place.
The bibliography uses biblatex with biber (Overleaf handles it automatically).
Open items: the author's approval of the AI-use statement; student on Relative Human (not evaluated); Figure 5.2 to be redrawn.
