# Answers from the cluster for the thesis (18 Oct 2026, evening; pasted by the student)

- Colour jitter: `grep -rn -i "jitter" --include=*.py . | grep -v archive` on the cluster copy returns NOTHING.
  No augmentation flag exists in the code: the thesis says no data augmentation was used (plan 7, Q8).
- In-training curves of the final model (job 3611336) and its control (job 3611339), per epoch, from the job logs
  (`sed -n 55,164p logs/exp7_final_model_3611336.out`, `sed -n 48,157p logs/exp7_final_model_3611339.out`):
  `val_curves_exp7.csv` in this folder (holdout = in-training AnnyOne holdout eval, V0 setting as train.py prints it,
  NOT the V1 trace number 73.7 / 77.4; 3dpwval = 3DPW-Anny validation, 300 images, v23 labels). Throughput: final
  10.9 img/s (A100-class), control 6.6 img/s (slower node): same recipe, different GPU.
- ViT-L history runs exist under logs/anny_model/: `anny_v7_scratch`, `anny_v8_resume_anny_partial_freeze` (plan 7, Q7);
  their last eval lines are still to be requested. Also present: anny_distill_vits_v7_mixed, anny_distill_vits_v8_final,
  evaltest_student_v8_final__threedpw_anny_v23 (a v8 ViT-S student already evaluated on the v23 labels at some point).
- Holdout trace folders in results/diagnostics/: holdout_anny_s2_shape_v5_00099 (and _rerun), holdout_anny_teacher_v9_00062,
  holdout_anny_teacher_v9_00149, holdout_anny_v10_00290..00293, manifest_trace_holdout_anny_s2_shape_v5_00099.
- per_person.csv header of the holdout traces (exp7 final and control, `holdout_ft/per_person.csv`): gid, gt_depth_m,
  pred_depth_m, root_depth_err_m, root_err_mm, root_px_err, head_px_err, pve, pa_pve, mpjpe, pve_headneck,
  pve_gtpose_predshape, pve_predpose_gtshape, neck_ratio, gt_skel_height_m, pred_skel_height_m, pheno_gt_* and
  pheno_pred_* and pheno_err_* for the 11 phenotypes, rot_* per region (rot_neck, rot_head, rot_fingers, ...),
  rot_global_head_deg, score, tags, variant, idx, person. -> F15 uses gt_depth_m vs pred_depth_m (variant = V1 rows).
- per_person.csv header of the Relative Human evals (`results/diagnostics/relative_human_val_<tag>/per_person.csv`):
  image, rh_index, age_group, gender, depth_id, gt_box_src, gt_x1..gt_y2, matched, iou, det_index, det_score,
  pred_gender, pred_age, pred_muscle, pred_weight, pred_height, pred_proportions, pred_cupsize, pred_firmness,
  pred_african, pred_asian, pred_caucasian, pred_x1..pred_y2. -> F16 uses age_group vs pred_age where matched is true.
- Jobs submitted 18 Oct evening for thesis figures: 3615018 (demo, predicted fingers, `run_demo_compare_hands.sh`),
  3615019 (demo, rest pose, Base + Final + Final-masked, `run_demo_compare_rest.sh`), 3615020_[2,4] (ViT-S students
  v6c and v8 on the v23 3DPW test labels). Run 3 (3614042) was RUNNING (33 min) at that time; student 3614191 pending.

## Demo montages received (job 3612078, Base v5 | Final, box placement, 18 Oct)
Saved under docs/thesis/figures/img/ as F10_photo_{garden,tennis,stage,party}_v5_vs_final.jpg and
F10_3dpw_{guitar,office,fencing}_v5_vs_final.jpg. Each montage: photo | Base | photo | Final, labels baked in
(anny_s2_shape_v5_00099 = Base, exp7_v5_final_00009 = Final). Still missing: downtown_bar, downtown_walking,
stairs (downtown_sitOnStairs), downtown_walkBridge/walking pair, weekly market (5 of the 8 3DPW frames).

## Zip batch 1 received (18 Oct, 21:20; thesis_figs_batch1.zip, 33 images + 5 CSVs)
- figures/img/F10_3dpw_{bar,runforbus,stairs,walking,market}_v5_vs_final.jpg: the 5 missing demo montages (job 3612078).
  All 12 montages are now present (4 photos + 8 3DPW test frames).
- figures/img/F21_age_sweep.jpg (diag_bodymodel), F14_label_check_{courtyard_arguing_00024 (two-person frame),
  downtown_walking_00771, climbing_00633, basketball_00570}.jpg (check_3dpw_conversion_v23/vis; 12 panels exist, 4 copied),
  exp6_compare_579864.jpg and exp6_compare_579866.jpg (F23), F12_holdout_<idx>_img_gt_v5_final.jpg x 6
  (panels: image | GT | Base | Final, each at its own depth; Base = v5 trace job 3570222, Final = exp7 holdout_ft).
- data/holdout_per_person_{final,control}.csv (exp7 final 3611336 and control 3611339 holdout traces; 834/836 rows;
  the per-person rows carry `variant` in {V0_eval_unmasked, V1_eval_masked, V2_demo, V3_demo_relaxhands}; use
  V1_eval_masked for the headline setting; columns gt_depth_m, pred_depth_m, root_err_mm, pve, ...).
- data/rh_per_person_{base,final,masked}.csv (Relative Human val, 2,130 people each; columns age_group, gender, matched,
  pred_age, pred_gender, ...; base = v5 job 3611285_0, final = job 3612131, masked = job 3613616).
- Not yet received: the v5 (Base) holdout trace per_person.csv (results/diagnostics/holdout_anny_s2_shape_v5_00099/per_person.csv)
  for the Base line of F15; the gt_decode overlays (F24; folder name unknown); the v7/v8 ViT-L run folders' contents.

## 18 Oct, 22:40: more logs from the student
- Student-S on the v23 3DPW test labels (job 3615020, `logs/eval-test3dpw-3615020_{2,4}.out`, all 8,190 images, V0 setting: run_eval_3dpw_test.sh, helper bones unmasked, as handover 0b states):
  - Student-S/6c (`anny_distill_vits_v6c_00149.pt`): AnnyOne test-100 PVE 114.5 / PA-PVE 84.6 / MPJPE 118.4, precision 81, recall 89;
    3DPW test PVE 142.6 / PA-PVE 91.0 / MPJPE 147.5, precision 45, recall 98.
  - Student-S/final (`anny_distill_vits_v8_final_00052.pt`): AnnyOne 120.6 / 86.9 / 125.0, precision 76, recall 87;
    3DPW test PVE 121.6 / PA-PVE 83.7 / MPJPE 123.3, precision 56, recall 98.
  -> fills the "Student-S on v23" TODO in chapter 6.11 / T20; the old-label numbers (139.5 -> 123.6) stay retired.
- Student (ViT-B, job 3614191) started training 21:23 on an L40S (serv-3313); checks PASS, teacher bone fix written; result ~20 h later.
- Demo figure jobs 3615018 (predicted fingers) and 3615019 (rest pose, Base/Final/Final-masked) finished; montages made on the
  login node (demo_montage_hands_{photos,3dpwtest}, demo_montage_rest_{photos,3dpwtest}); zip batch 2 (45 MB) ready on the cluster,
  not yet uploaded here.
- v7/v8 ViT-L history runs have checkpoints and tfevents only, no train.log: dropped from the thesis history.

## Zip batch 2 received (19 Oct, 00:05; three zips)
- F11 predicted fingers (demo job 3615018, --relax_hands 0, Base | Final, 2 panels each): figures/img/F11_hands_photo_{garden,tennis,stage,party}.jpg,
  F11_hands_3dpw_{bar,guitar,office,market,walking,fencing,stairs,runforbus}.jpg. Caption note: Base's metacarpal1.L is flipped in these
  renders (the correction is only in Final), so Base's left index base looks bent backwards.
- F17 rest-pose line-up (demo job 3615019, --rest_pose 1, Base | Final | Final-masked, 3 panels): F17_rest_photo_{garden,tennis,stage,party}.jpg,
  F17_rest_3dpw_{...}.jpg (same eight frames).
- F12 proper V1 holdout montages (image | GT | Base V1 | Final V1, 672-px panels, 4-px gaps): F12_holdout_<idx>_img_gt_base_final.jpg x 6.
- F24 ground-truth decode overlays (check 1): F24_gt_decode_1..4.jpg (holdout 579888 p0, holdout 579925 p0, train 462901 p0, train 326611 p3);
  data/gt_decode_summary.json.
- Demo logs: data/demo_compare_3615018_hands.log, data/demo_compare_3615019_rest.log (the [shape] lines per detection for the spread numbers).

## 19 Oct, 00:30: Final-partial-mask (run 3, job 3614042) DONE; its Relative Human eval submitted as job 3616821
- Holdout V1 (compare table, last column, `logs/exp7_final_model_3614042.out:191-215`): PVE 73.0, PA-PVE 51.2, recall 87.4,
  root error 680 mm, depth slope 0.42 (intercept 1.69 m), size ratio 0.79, girth 1.005, neck PVE 10.5 mm, global head 13.2 deg,
  fingers 8.2 deg, neck02 5.0, head 8.9, finger4-1.R 9.2, metacarpal1.L 0.0; verdicts OK; neck kept, depth kept, cost vs control kept.
  Bone fix estimated for this run: neck02 178.8, head 179.2, metacarpal1.L 179.8, finger4-1.R 179.7 deg.
- AnnyOne test-100 V0 (run_eval_3dpw_test.sh): PVE 76.6, PA-PVE 55.2, precision 81, recall 87, MPJPE 77.9.
- 3DPW test v23, all 8,190 images: PVE 89.9, PA-PVE 58.9, precision 66, recall 99, MPJPE 90.0.
  (Final: 73.7 / 50.3 / 87.0; root 728; 3DPW 89.0 / 57.6 / 64 / 99. Final-masked: 71.7 / 50.7 / 86.2; 3DPW 91.1 / 59.0.)
- Everything is within the run-to-run noise of Final; the decision rests on Relative Human (job 3616821) and the demo spread.

## 19 Oct, 01:20: Relative Human of Final-partial-mask (job 3616821, `logs/eval_rh_3616821_0.out`) -> DECISION: unmasked Final stays
- val, 635 images, 2,130 people, iou 0.3, child_thr 0.45: overall recall 0.630 (1341/2130).
  adult n_lab 1680 matched 1086 recall 0.646 age mean 0.532 (median 0.524) <thr 0.003 height 0.527 g_acc 0.468 (n 1050);
  teen 101 / 70 / 0.693 / 0.515 / 0.513 / 0.000 / 0.520 / 0.500 (68); kid 209 / 117 / 0.560 / 0.506 / 0.505 / 0.103 / 0.497 / 0.495 (107);
  baby 117 / 67 / 0.573 / 0.465 / 0.478 / 0.343 / 0.504 / 0.556 (45).
  child-vs-adult AUC 0.727 (n_pos 184, n_neg 1086); gender accuracy 0.474 (n 1271), pred gender mean male 0.725, female 0.888.
- Rule (gender >= 60%, AUC >= 0.7, spread opened): gender FAILS (47.4%), AUC passes (0.727), spread not measured (no demo run; not needed).
  -> The unmasked Final (3611336) remains the thesis model and the Student's teacher. Final-partial-mask is the fourth column of
  the shape-mask trade-off (chapter 6.8, Table 6.2): children kept (age label kept), gender lost like the full mask.
- Reading, untested: the gender label was still supervised here and gender accuracy still collapsed (both sexes predicted
  female-side), so Final's gender gain likely depends on the seven 0.5 constants on 3DPW men (cup size, firmness, ...) as much as on
  the gender label. Not tested further.

## 19 Oct morning: STUDENT DONE (job 3614191, `logs/exp8_distill_vitb_3614191.out`) -> 95% rule FAILS
- Training: 30 epochs x 1000 x batch 8 on an L40S, 20,894 s (5.8 h), 11.6 img/s; 77 NaN/Inf steps skipped; heads frozen epochs 0-4.
  In-training curve (V0 holdout PVE / 3DPW-val PVE) at epochs 5, 10, 15, 20, 25, 30: 165.1/104.9, 170.0/101.5, 139.5/93.0,
  133.0/90.9, 130.5/88.0, 122.8/87.7 (log lines 59-143). AnnyOne still falling ~8 mm per 5 epochs; 3DPW-val flat (88.0 -> 87.7).
- Student bone fix (own estimate): neck02 178.9, head 179.1, metacarpal1.L 179.7, finger4-1.R 179.9 deg (0.2-1.8 deg from the teacher's);
  holdout with own fix 119.6 vs with the teacher's 119.7 (no difference).
- Holdout V1 (lines 195-207): student PVE 119.6, PA-PVE 80.8, MPJPE 127.2, recall 85.4, FP 64; teacher 73.7 / 50.3 / 77.9 / 87.0, FP 42.
  Region rotation errors (deg) student vs teacher: root 13.5 vs 8.7, spine 6.5/5.8, neck 5.7/5.5, head 4.5/5.0, arm 10.6/8.4,
  fingers 9.3/8.3, leg 6.4/5.1. Root error 830.7 vs 728.5 mm.
- AnnyOne test-100 V0: student 122.7 / 84.2 / 127.7, recall 85; teacher 77.5 / 54.4 / 78.5, recall 87.
- 3DPW test v23 (8,190 images): student PVE 110.1, PA-PVE 71.8, MPJPE 112.0, recall 99; teacher 89.0 / 57.6 / 88.3 / 99.
- Cost on an L40S (lines 213-221): teacher 318.38 M / 1927.4 GFLOPs / 59.7 ms full (50.7 ms backbone); student 101.38 M (backbone 86.58,
  feat_proj 0.79, heads 14.01) / 603.3 GFLOPs / 28.5 ms full (19.1 ms backbone); 3.14x fewer params, 3.19x fewer FLOPs, 2.10x faster.
- Final table (lines 259-283): bars AnnyOne PVE <= 77.6, MPJPE <= 82.0; 3DPW PVE <= 93.7, MPJPE <= 92.9. VERDICT: FAIL on all four.
- Against Multi-HMR-Anny (NAVER): 3DPW 110.1 vs 126.9 mm (student better), 101.38 vs 380.94 M params (3.76x fewer);
  AnnyOne 119.6 vs 60.3 (NAVER likely in-sample). Against NAVER's bars (63.5 / 133.6): 3DPW met, AnnyOne not met.

## PENDING exp9 (supervisor 22 Oct: KD temperature sweep + loss curves; `slurm/experiments/exp9_kd_temperature.sh`, not yet submitted)
Launch: `CHECK_ONLY=1 bash slurm/experiments/exp9_kd_temperature.sh`, then `bash slurm/experiments/exp9_kd_temperature.sh`
(5 jobs: T 1, 2, 4, 8, 16; RUN `student_vitb_from_v5_pc_dist5_bonefix_v23_e10_00009_e30_kdT<t>_sweep`; ~7.5 h wall each on an L40S).
Send back, when the jobs are done:
- the launcher's output (the five `submitted: job <id>` lines) or `logs/exp9_kd_temperature_<date>.txt` (temperature, RUN, job id);
- per job: `logs/exp8_distill_vitb_<jobid>.out` (its `=== 6. FINAL TABLE` block and VERDICT) and, from
  `results/experiments/exp8_distill_vitb/<RUN>/`: `final_table.json`, `settings.txt`, `train_lines.log` (or `train.log`),
  `holdout_student/summary.json`, `eval_3dpw_test_student.log`;
- the collector's outputs: `results/experiments/exp9_kd_temperature/kd_temperature_sweep.csv`, `.png`, `.pdf` and the stdout of
  `python scripts/analysis/kd_temperature_sweep.py --runs "results/experiments/exp8_distill_vitb/student_vitb_from_v5_pc_dist5_bonefix_v23_e10_00009_e30_kdT*_sweep" --reported results/experiments/exp8_distill_vitb/student_vitb_from_v5_pc_dist5_bonefix_v23_e10_00009_e30 --out results/experiments/exp9_kd_temperature`
  (the per-metric minima, the PICK line, the T 4 run-to-run noise line);
- the loss curves: `results/experiments/exp9_kd_temperature/loss_curves/<RUN>_loss_curves.{png,pdf,csv}` and the printed slopes +
  VERDICT lines of `python scripts/analysis/plot_loss_curves.py <run folders> --out results/experiments/exp9_kd_temperature/loss_curves`,
  run on the five sweep folders AND, already now, on the two finished runs
  `results/experiments/exp8_distill_vitb/student_vitb_from_v5_pc_dist5_bonefix_v23_e10_00009_e30` (job 3614191) and
  `..._e60` (job 3623342): train loss + validation PVE every 5 epochs, no validation loss (the old runs predate `--val_loss`).

## 6 Nov: loss curves of the 30- and 60-epoch students (`scripts/analysis/plot_loss_curves.py`, source tensorboard)

Neither run has a validation loss (trained without `--val_loss`); the in-training validation PVE stands in for it.
Slopes over the last 20% of epochs, as printed on login1:

| run | train loss total | val PVE AnnyOne holdout (in-training) | val PVE 3DPW-val (300 imgs) |
|---|---|---|---|
| e30 (job 3614191) | 130.67 -> 124.12, -0.87%/epoch, falling | 130.49 -> 122.83, -1.21%/epoch, falling | 88.03 -> 87.75, -0.06%/epoch, flat |
| e60 (job 3623342) | 120.53 -> 115.75, -0.29%/epoch, falling | 117.46 -> 113.04, -0.38%/epoch, falling | 85.47 -> 85.96, +0.06%/epoch, flat |

Reading [Certain for the numbers]: doubling the epochs bought ~10 mm in-training holdout PVE (122.8 -> 113.0) and
~2 mm on 3DPW-val (87.8 -> 86.0); on AnnyOne both curves still fall but 3.4x slower than at epoch 30; on 3DPW the
validation error has been flat since about epoch 25 while the training loss still falls, so more epochs do not help
there (the script's word "over-fitting" means "no further validation gain"; the validation error is not rising).
[Likely] another doubling would give a few mm on AnnyOne and nothing on 3DPW; no run length reaches the 77.6 / 93.7
bars. The in-training holdout PVE is not the final V1 test protocol (e30: 122.8 in-training vs 119.6 reported);
the e60 run's final test numbers (`final_table.json`) are still to be sent.
Figures: `results/experiments/exp9_kd_temperature/loss_curves/*_loss_curves.{png,pdf,csv}` on the cluster.

## 6 Nov: 60-epoch student final table (job 3623342, `<RUN ..._e60>/final_table.json`, checkpoint 00059.pt)

| metric | teacher | e30 student (3614191) | e60 student (3623342) | 95% bar | met (e60) |
|---|---|---|---|---|---|
| AnnyOne holdout V1 PVE | 73.7 | 119.6 | **107.7** | 77.6 | no |
| AnnyOne holdout V1 PA-PVE | 50.3 | 80.8 | 74.6 | (53.0) | no |
| AnnyOne holdout V1 MPJPE | 77.9 | 127.2 | 114.5 | 82.0 | no |
| AnnyOne holdout recall | 87.0 | 85.4 | 85.0 | | |
| AnnyOne holdout root error mm | 728.5 | | 697.9 | | |
| 3DPW test PVE | 89.0 | 110.1 | **110.9** | 93.7 | no |
| 3DPW test PA-PVE | 57.6 | 71.8 | 72.5 | (60.6) | no |
| 3DPW test MPJPE | 88.3 | 112.0 | 112.9 | 92.9 | no |
| 3DPW test recall | 99 | 99 | 99 | | |
| params M / GFLOPs | 318.4 / 1927.4 | 101.4 / 603.3 | 101.4 / 603.3 | | yes |
| inference ms (this job's bench) | 60.6 | 28.5 (3614191 bench, teacher 59.7) | 28.9 | | yes |

Verdict FAIL on all four in-rule errors. Reading [Certain]: 60 epochs improve AnnyOne by 11.9 mm PVE (119.6 -> 107.7)
and leave 3DPW unchanged (110.1 -> 110.9, within noise), exactly what the loss curves predicted. The thesis keeps the
30-epoch run as the reported student unless the author switches; if the e60 run is reported instead, every student
number in the thesis and deck changes and the e30 run becomes the "longer training" ablation.

Additional rows of the same e60 `final_table.json` (as pasted by the author on 6 Nov): AnnyOne test-100 (evaluate(), V0):
teacher PVE 77.5 / PA-PVE 54.4 / MPJPE 78.5 / recall 87.0; e60 student 111.0 / 78.2 / 115.0 / 85.0. Training throughput
(not comparable between the two): teacher 10.93, student 11.54 images/s. Learning-rate schedule of the e60 run: exp8's
default LR_DECAY_EVERY = 2/5 of EPOCHS (`slurm/experiments/exp8_distill_vitb.sh` header, "StepLR x0.5 every
LR_DECAY_EVERY"), i.e. x0.5 every 24 epochs; EVAL_FREQ 5 (exp8 default).

## 7 Nov: five-panel video run = job 3657550 (`results/video_compare/video_3657550/`, run.json + timing.csv as pasted)

NVIDIA A40, fp32 with TF32, 672 px, batch 1, 346 timed frames after 10 warm-up frames; man_walking.mp4, 356 frames at
29.97 FPS. timing.csv: Student inference 54.51 ms mean = 18.35 FPS; student_temporal processing 67.23 ms = 14.87 FPS
(filter + re-decode 12.72 ms); student_aligned processing 77.39 ms = 12.92 FPS (alignment fit 10.16 ms); baseline
(multiHMR_672_L_anny) 117.65 ms = 8.50 FPS; ratio 2.16. Matches: Student 356/356, baseline 354/356 (this run's
summaries). Filter constants as defaults (pose 0.08 s, translation 0.12 s, shape 1.0 s, gap 0.25 s, depth 0.35 s);
MediaPipe Pose 0.10.14 on CPU, 12 landmarks, all 356 frames accepted. Motion proxies (run.json summaries, not accuracy):
mean pelvis-relative joint acceleration raw 38.0, temporal 10.5, aligned 10.5, baseline 29.6 m/s^2; mean root speed
raw 1.69, temporal 0.63, aligned 0.53, baseline 1.52 m/s; gender std over the clip raw 0.058, temporal 0.024.
Temperature sweep jobs (submitted 6 Nov 16:39, pending 7 Nov): T=1 3717507, T=2 3717530, T=4 3717538, T=8 3717581,
T=16 3717598.

## 7 Nov: exp9 temperature sweep, first arm done. T=1 (job 3717507, COMPLETED 07:20:44, exit 0; `[val_loss]` lines present every epoch, no Traceback)

`<RUN>_kdT1_sweep/final_table.json`: holdout V1 PVE 116.0 / PA-PVE 77.8 / MPJPE 123.1; AnnyOne test-100 V0 119.2 / 81.3 /
123.6; 3DPW test 109.9 / 71.0 / 111.6; verdict FAIL (same four rows as the reported T=4 run). Compared with the reported
T=4 run (119.6 / 80.8 / 127.2; 110.1 / 71.8 / 112.0): 3.6 mm better on the holdout, 0.2 mm on 3DPW, both within the
run-to-run noise (7.6 mm PVE). T=2 (3717530) and T=4 sweep (3717538) running; T=8 (3717581) and T=16 (3717598) pending.

## 8 Nov: exp9 temperature sweep done (collector output pasted on login1; data/kd_temperature_sweep.csv)

T=1 3717507, T=2 3717530 (7h19), T=4 3717538 (13h17, RTX A6000), T=8 3717581 (13h28): COMPLETED. T=16 3717598 FAILED
after 6h38: training finished ("NaN/Inf gradient steps skipped: 84"), then a post-training step raised
urllib.error.HTTPError 504 Gateway Timeout (a download), so no final table. Holdout PVE 116.0 / 116.7 / 117.1 / 117.1;
3DPW PVE 109.9 / 106.8 / 110.1 / 107.1. Collector PICK T=2 (holdout/77.6 + 3DPW/93.7 = 2.644); no arm meets a 95% bar.
Noise (sweep T4 - reported T4): holdout PVE -2.5, 3DPW 0.0 mm. Teacher re-measured 73.7 / 88.9-89.0 in every arm.
Reading: the temperature has no effect beyond the run-to-run noise; T=4 is kept.

## PENDING exp10, remaining items (supervisor feedback 12 Nov; `docs/experiments_plan.md` "exp10")

Items 1 (sweep validation table) and 2 (distillation ablation) of the original request arrived on 13 Nov and are
recorded in the section "13 Nov: exp10 results" below. Still pending, send back:

3. **T 16 sweep arm** (`POST_ONLY=1 KD_T=16 ... RUN=..._kdT16_sweep bash slurm/experiments/exp8_distill_vitb.sh`):
   `logs/exp8_distill_vitb_<jobid>.out` (FINAL TABLE block), `<RUN>/final_table.json`, and the re-run collector
   `scripts/analysis/kd_temperature_sweep.py` (stdout + `results/experiments/exp9_kd_temperature/kd_temperature_sweep.{csv,png,pdf}`),
   which then has all five temperatures.
4. **Student on Relative Human** (`MODEL=.../00029.pt BONE_FIX=.../bone_fix.json TAG=student_vitb_e30_00029 sbatch --array=0 slurm/diagnostics/eval_relative_human.sh`):
   `results/diagnostics/relative_human_val_student_vitb_e30_00029/per_person.csv` and `summary.txt` (= the `[rh]`
   summary lines of `logs/eval_rh_<jobid>_0.out`: the per-group table, the AUC line, the gender line, `overall recall`),
   plus the log's `[load_model]` lines (`bone_fix: <path>`, `feat_proj=yes ... backbone=dinov2_vitb14 head_dim=1024`).
   Then the stdout of `scripts/analysis/rh_recall_by_crowd.py student=... final=...` and
   `results/analysis/rh_recall_by_crowd/rh_recall_by_crowd.{csv,md}`.
   The released baseline (`multiHMR_672_L_anny.pt`) cannot be run through this evaluation (original model class).

## 13 Nov: exp10 results (distillation ablation; validation values of the temperature sweep)

### A. Distillation ablation (launcher record `logs/exp10_kd_ablation_20261112_225014.txt`)

Submitted 12 Nov 2026, 22:50, git 7b7edf1, by `slurm/experiments/exp10_kd_ablation.sh`. Both jobs COMPLETED, about
6 h each. Same data, schedule (30 epochs), architecture and backbone initialisation as the student; one run each; last
checkpoint; each arm's own bone correction estimated after training.

- Arm 1, the student without distillation losses: run `student_vitb_from_v5_pc_dist5_bonefix_v23_e10_00009_e30_nokd`,
  job 3744297. Both distillation losses off; teacher heads still copied, frozen for the first 5 epochs, teacher bone
  correction used in training.
- Arm 2, the ViT-B model without teacher: run `student_vitb_from_v5_pc_dist5_bonefix_v23_e10_00009_e30_supervised`,
  job 3744307. No teacher at all (no distillation losses, no head copy, no freeze, no teacher bone correction in
  training).

Final test numbers (holdout protocol on the 100 AnnyOne holdout images; 3DPW test, 8,190 images, 3DPW protocol),
PVE / PA-PVE / MPJPE (mm) / recall (%):

| Model | AnnyOne holdout | 3DPW test |
|---|---|---|
| Student (reported, job 3614191) | 119.6 / 80.8 / 127.2 / 85.4 | 110.1 / 71.8 / 112.0 / 99.0 |
| Student, repeat run (T=4 sweep run) | 117.1 / 81.4 / 124.2 / 85.8 | 110.1 / 72.0 / 111.5 / 100.0 |
| Without distillation losses (3744297) | 118.2 / 79.7 / 125.3 / 85.0 | 110.0 / 71.6 / 111.6 / 100.0 |
| Without teacher (3744307) | 122.6 / 81.0 / 130.0 / 85.4 | 116.7 / 79.1 / 123.1 / 99.0 |
| Teacher | 73.7 / 50.3 / 77.9 / 87.0 | 89.0 / 57.6 / 88.3 / 99.0 |

Holdout root error: without distillation losses 911.7 mm; without teacher 799.5 mm.

In-training validation at the final epoch (3DPW protocol; 300 3DPW validation images; AnnyOne holdout as monitor):
3DPW-val PVE, PA-PVE, MPJPE; holdout PVE (mm):
- Student reported: 87.7, 60.6, 86.9; 122.8
- Repeat: 86.2, 60.7, 85.2; 118.4
- Without distillation losses: 86.1, 61.2, 85.1; 122.9
- Without teacher: 91.5, 66.7, 97.3; 131.9

Validation loss at the final epoch on the 3DPW validation images: supervised part ("task") 48.40 (repeat), 48.25
(without distillation losses), 50.14 (without teacher). Feature-distillation term measured as a monitor: 13.0 for the
repeat (trained with it) against 306.0 for the arm without distillation losses; output-distillation term 10.4 against
11.8.

Differences (mm):
- repeat minus reported (run-to-run): holdout PVE -2.5; 3DPW PVE 0.0; 3DPW MPJPE -0.5; 3DPW-val PVE -1.5.
- without losses minus repeat: holdout PVE +1.1, MPJPE +1.1; 3DPW PVE -0.1, MPJPE +0.1; 3DPW-val PVE -0.2.
- without teacher minus repeat: holdout PVE +5.5, MPJPE +5.8; 3DPW PVE +6.6, PA-PVE +7.1, MPJPE +11.6; 3DPW-val PVE +5.2.
- without teacher minus without losses: 3DPW PVE +6.7, MPJPE +11.5; holdout PVE +4.5.

Both arms fail the same 95 % retention thresholds as the student. Inference times of the two arms are not reported
(same architecture as the student; the second job was timed under different load).

Reading: removing the distillation losses changes no accuracy value by more than the run-to-run difference (no
measurable effect in this configuration; the feature term keeps the student's features close to the teacher's, 13.0
against 306.0, without lowering the error). Removing the teacher altogether costs 6.6 mm PVE and 11.6 mm MPJPE on 3DPW
test (5.5 mm PVE on the holdout): the benefit of the teacher comes through the transferred heads (with warm-up freeze
and teacher bone correction in training), not through the distillation losses. Not separated: head copy, freeze and
bone correction; one run per arm; the arm without teacher used the schedule and learning rate chosen for transferred
heads; no other distillation weights or feature layers were tried.

### B. Validation values of the temperature sweep (`scripts/analysis/sweep_validation_table.py`)

Final epoch; 3DPW protocol with the training bone correction; 300 images of the 3DPW validation split; AnnyOne holdout
as monitor. Columns: 3DPW-val PVE / PA-PVE / MPJPE; holdout PVE; best 3DPW-val PVE (epoch); final minus best (mm).

| Run | 3DPW-val PVE / PA-PVE / MPJPE | holdout PVE | best 3DPW-val PVE (epoch) | final - best |
|---|---|---|---|---|
| T=1 | 86.7 / 61.2 / 85.6 | 119.4 | 85.4 (29) | +1.2 |
| T=2 | 87.7 / 61.4 / 86.7 | 121.2 | 86.3 (29) | +1.4 |
| T=4 (sweep run) | 86.2 / 60.7 / 85.2 | 118.4 | 85.0 (29) | +1.3 |
| T=8 | 85.2 / 60.8 / 84.0 | 122.8 | 84.9 (29) | +0.3 |
| T=16 | 85.5 / 60.4 / 84.1 | 123.4 | 85.1 (29) | +0.4 |
| Reported student (T=4, 30 epochs, evaluated every 5 epochs) | 87.7 / 60.6 / 86.9 | 122.8 | - | - |
| 60-epoch student | 86.0 / 60.2 / 85.0 | 113.0 | 84.8 (55) | +1.2 |

Spread over the five temperatures on 3DPW-val PVE: 2.6 mm (lowest T=8, highest T=2). Two runs of the same T=4
configuration differ by 1.5 mm on the same images. Recall 100 % everywhere. The T=16 run has validation values
(training finished) but still no test evaluation.

Reading: the temperature changes the 3DPW validation PVE by at most 2.6 mm against 1.5 mm between two identical runs;
selection on validation would have favoured T=8 by 1.0 mm over the T=4 repeat, which is not interpreted; T=4 was fixed
beforehand and is kept; the last checkpoint is at most 1.4 mm above the best epoch.

Note: the reported student's 3DPW-val PVE was recorded on 6 Nov from tensorboard as 87.75 (thesis macro
`\SelThirtyValPVE` = 87.8); the script prints 87.7 (the same value 87.75 formatted to one decimal by Python, which rounds the binary value 87.7499... down).
The thesis now uses 87.7 throughout, so that the differences above (repeat minus reported -1.5) add up.
